# StopWatch

It is simple Stopwatch created using Swing Components.Application look like below Picture :)
<img src="/2018-07-26 (1).png" alt="My cool logo"/>
